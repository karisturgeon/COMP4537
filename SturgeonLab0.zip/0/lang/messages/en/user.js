const MESSAGES = {
    instructions: "How many buttons to create?",
    goButton: "Go!",
    wrongOrder: "Wrong order!",
    win: "Excellent memory!",
    incorrectNumber: "Please enter a valid number between 3 and 7."
}